const GalleryItems = require('../models/galleryItems.model');

const express = require('express');
const router = express.Router();


const multer = require('multer');
const upload = multer({

    storage: multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, 'public/images');
        },
        filename: function (req, file, cb) {
            cb(null, Date.now() + '-' + file.originalname)
            //cb(null, file.originalname)
        }
    })
});




// ----- HENT/GET ALLE ------------------------------------------------------------------------------------------

router.get('/', async (req, res) => {

    console.log("HENT ALLE galleryitem");

    try {
        const galleryitem = await GalleryItems.find().populate('service');

        res.json(galleryitem);

    } catch (err) {
        res.status(500).json({ message: "Der var en fejl i / :" + err.message }); // 500 = serverproblem
    }

});



// ----- OPRET/POST NY - ADMIN ---------------------------------------------------------------------------------------

router.post('/admin',  upload.single('image'), async (req, res) => {

    console.log("POST", req.body);

    const galleryitem = new GalleryItems(req.body);

    let filename = req.file ? req.file.filename : "paavej.jpg";
    galleryitem.image = filename;      // filename kommer ikke automatisk med i request

    try {
        const ny = await galleryitem.save();
        res.status(201).json({ message: "Ny er oprettet", galleryitem: ny });

    } catch (error) {
        res.status(400).json({ message: "Der er sket en fejl", error: error });
    }

});

module.exports = router;