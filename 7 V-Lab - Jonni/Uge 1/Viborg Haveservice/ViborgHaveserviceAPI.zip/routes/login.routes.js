const User = require('../models/users.model');

const express = require('express');
const router = express.Router();



// ----- LOGIN (tilføj session hvis match) ---------------------------------------------------------------------------------

router.post('/login', async (req, res) => {

    console.log("LOGIN");

    try {

        const { email, password } = req.body;

        const user = await User.findOne({ email: email });

        if (!user) {
            // slet cookie - så en evt. tidligere succes bliver slettet når man forsøger at logge ind med forkert
            //TODO: res.clearCookie(process.env.SESSION_NAME).json({ message: "2. Bruger, email og/eller password findes ikke" });
            // http status koden 400 laver automatisk en error 
            return res.status(401).json({ message: "1. Bruger findes ikke" })
        }


        user.comparePassword(password, function (err, isMatch) {

            if (err) throw err;
            console.log('Password: ', isMatch); //

            if (isMatch) {

                req.session.userId = user._id // LAV SESSION med brugers id

                res.json({ email: user.email, brugerID: user._id });

            } else {
                // slet cookie - så en evt. tidligere succes bliver slettet når man forsøger at logge ind med forkert
                res.status(401).clearCookie(process.env.SESSION_NAME).json({ message: "2. Bruger findes ikke" });
            }
        });

    } catch (err) {
        res.status(500).json({ message: err.message }); // 500 = serverproblem
    }

});


// ----- LOGUD (destroy session) -------------------------------------------------------------------------------------------- 
// ----- GET http://localhost:5021/login/logout

router.get('/logout', async (req, res) => {

    console.log("LOGUD")

    // destroy - se express-session dokumentation - destroy vs clearcookie https://stackoverflow.com/a/58142467
    req.session.destroy(err => {

        // FEJL
        if (err) return res.status(500).json({ message: 'Logud lykkedes ikke - prøv igen' }) // hvis fejl/ikke kan destroy så send til ???

        // OK send response som sletter cookie hos klienten
        res.clearCookie(process.env.SESSION_NAME).json({ message: 'cookie slettet' });

    })

});



// ----- LOGGET IND? true eller false --------------------------------------------------------------------------------------- 
// ----- GET http://localhost:5021/login/loggedin

router.get('/loggedin', async (req, res) => {

    console.log("LOGGED IN?")

    // Jeg gemmer userId i cookie - så derfor spørger jeg om den er der = logget ind
    if (req.session.userId) {
        // Hvis der er logget ind
        return res.status(200).json({ message: 'Login er stadig aktiv' }) //route

    } else {
        // Hvis der ikke er et login/en session
        return res.status(401).json({ message: 'Login eksisterer ikke eller er udløbet' })
    }

})


module.exports = router;