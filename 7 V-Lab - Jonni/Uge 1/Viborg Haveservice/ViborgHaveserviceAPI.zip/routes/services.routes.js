const Services = require('../models/services.model');

const express = require('express');
const router = express.Router();


const multer = require('multer');
const upload = multer({

    storage: multer.diskStorage({
        destination: function (req, file, cb) {
            cb(null, 'public/images');
        },
        filename: function (req, file, cb) {
            cb(null, Date.now() + '-' + file.originalname)
            //cb(null, file.originalname)
        }
    })
});


// ----- HENT/GET ALLE ------------------------------------------------------------------------------------------

router.get('/', async (req, res) => {

    console.log("HENT ALLE");

    // Hent medsendte query - dem efter ?limit
    // Hvis limit kan være et heltal et ikke-ikkenummer
    let limit;
    if (req.query.limit) {
        if (!isNaN(parseInt(req.query.limit))) limit = parseInt(req.query.limit);
    }


    console.log(limit)

    try {
        const services = await Services.find().limit(limit);//.populate('galleryitems');
        res.json(services);

    } catch (err) {
        res.status(500).json({ message: "Der var en fejl i:" + err.message }); // 500 = serverproblem
    }

});


// ----- HENT/GET UDVALGT  ------------------------------------------------------------------------------------------------------------- 

router.get('/:id', findService, async (req, res) => { //

    console.log("HENT UDVALGT")

    res.json(res.service);

});


// ----- OPRET/POST NY - ADMIN ---------------------------------------------------------------------------------------

//router.post('/admin', upload.any('image', 'galleryItems'), async (req, res) => {
router.post('/admin', upload.single('image'), async (req, res) => {

    console.log("POST");

    let service;

    try {

        if (req.body.service) {
            service = new Services({
                ...JSON.parse(req.body.service),
                "image": req.file.filename
            })
        } else {
            service = new Services(req.body);
            service.image = req.file ? req.file.filename : "paavej.jpg"; // filename kommer ikke automatisk med i request
        }

        const ny = await service.save();
        res.status(201).json({ message: "Ny er oprettet", service: ny });

    } catch (error) {
        res.status(400).json({ message: "Der er sket en fejl", error: error });
    }

});



// ----- SLET/DELETE - ADMIN ------------------------------------------------------------------------------------------------------------ 

router.delete('/admin/:id', findService, async (req, res) => {

    console.log("DELETE")

    try {

        await res.service.remove();
        res.status(200).json({ message: 'Der er nu slettet' })

    } catch (error) {
        res.status(500).json({ message: 'Kan ikke slettes - der er opstået en fejl: ' + error.message })
    }



});

// ----- RET/PUT - ADMIN ------------------------------------------------------------------------------------------------------------ 

router.put('/admin/:id', upload.single('image'), findService, async (req, res) => {

    console.log("PUT", res.service)

    try {

        let service;

        if (req.body.service) {
            service = JSON.parse(req.body.service)
        } else {
            service = req.body
        }

        res.service.title = service.title;
        res.service.content = service.content;


        // fra multer - skal kunne håndtere at billedet måske ikke skal udskiftes
        if (req.file) {
            res.service.image = req.file.filename;
        }

        await res.service.save();

        res.status(200).json({ message: 'Der er rettet', rettet: res.service });

    } catch (error) {
        res.status(400).json({ message: 'sponsor kan ikke rettes - der er opstået en fejl: ' + error.message })
    }

});



// MIDDLEWARE 

// FIND UD FRA ID  ---------------------------------------------------------------------------------------------

async function findService(req, res, next) {

    console.log("FIND UD FRA ID", req.params.id)
    let service;

    try {

        service = await Services.findById(req.params.id);

        if (service == null) {
            return res.status(404).json({ message: 'Ingen med den ID' });
        }


    } catch (error) {

        console.log(error);
        return res.status(500).json({ message: "Problemer: " + error.message }); // problemer med server
    }

    res.service = service; // put det fundne ind i responset
    next();
}


module.exports = router;