const Toast = require('../models/toast.model');

const express = require('express');
const formData = require('express-form-data');              // HVIS der bruges multer et sted så skal denne kun placeres i routes UDEN multer!!!

const router = express.Router();
router.use(formData.parse());


// ----- HENT/GET ONE ------------------------------------------------------------------------------------------

router.get('/', async (req, res) => {

    console.log("HENT TOAST");

    try {
        const toast = await Toast.findOne();

        res.json(toast);

    } catch (err) {
        res.status(500).json({ message: "Der var en fejl i: " + err.message }); // 500 = serverproblem
    }

});



// ----- RET/PUT - ADMIN ------------------------------------------------------------------------------------------------------------ 
// Kun ret - der skal ikke oprettes nye/slettes - kun rettes i den eksisterende

router.put('/admin/', async (req, res) => {

    console.log("PUT")

    try {

        const toast = await Toast.findOne();
        
        toast.title = req.body.title;
        toast.content = req.body.content;
        await toast.save();

        res.status(200).json({ message: 'Der er rettet', rettet: toast });

    } catch (error) {
        res.status(400).json({ message: 'Der kan ikke rettes - der er opstået en fejl: ' + error.message })
    }

});






module.exports = router;