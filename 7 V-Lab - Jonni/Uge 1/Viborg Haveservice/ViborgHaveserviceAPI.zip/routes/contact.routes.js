const Contact = require('../models/contacts.model');

const express = require('express');
const formData = require('express-form-data');              // HVIS der bruges multer et sted så skal denne kun placeres i routes UDEN multer!!!

const router = express.Router();
router.use(formData.parse());                               // nødvendig for at kunne modtage formdata fx 'e.target' fra react/frontend




// ----- HENT/GET ONE ------------------------------------------------------------------------------------------
// :xtra? fordi Daniels version leder efter /1

router.get('/:xtra?', async (req, res) => {

    console.log("HENT");

    try {
        const contact = await Contact.findOne();

        res.json(contact);

    } catch (err) {
        res.status(500).json({ message: "Der var en fejl i: " + err.message }); // 500 = serverproblem
    }

});



// ADMIN ROUTES  -----------------------------------------------------------
// *************************************************************************


// ----- RET/PUT ------------------------------------------------------------------------------------------------------------- 

router.put('/admin', async (req, res) => {

    console.log("PUT")

    try {

        const contact = await Contact.findOne();
        contact.address = req.body.address;
        contact.openhours = req.body.openhours;
        contact.contactinformation = req.body.contactinformation;
        await contact.save();

        res.status(200).json({ message: 'Der er rettet', rettet: contact });

    } catch (error) {
        res.status(400).json({ message: 'Kan ikke rettes - der er opstået en fejl: ' + error.message })
    }

});





module.exports = router;