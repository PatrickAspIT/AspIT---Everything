const Users = require('../models/users.model');

const express = require('express');
const formData = require('express-form-data');              // HVIS der bruges multer et sted så skal denne kun placeres i routes UDEN multer!!!

const router = express.Router();
router.use(formData.parse());  


// ----- HENT/GET ALLE - ADMIN -----------------------------------------------------------------------------------------

router.get('/admin', async (req, res) => {

    console.log("HENT ALLE");

    try {
        const user = await Users.find();

        res.json(user);

    } catch (err) {
        res.status(500).json({ message: "Der var en fejl i: " + err.message }); // 500 = serverproblem
    }

});


// ----- HENT/GET UDVALGT  ------------------------------------------------------------------------------------------------------------- 

router.get('/admin/:id', findUser, async (req, res) => { //

    console.log("HENT UDVALGT")

    res.json(res.user);

});


// ----- OPRET/POST NY - ADMIN ---------------------------------------------------------------------------------------

router.post('/admin', async (req, res) => {

    console.log("POST");

    try {

        let user = await Users.findOne({ email: req.body.email })

        if (user) {

            console.log("USER findes i forvejen = kan ikke oprettes igen")
            return res.status(401).json({ message: "User findes allerede (OBS - denne besked skal laves om - GDPR!" })

        } else {

            console.log("USER findes IKKE i forvejen")
            user = new Users(req.body);
            const ny = await user.save();
            res.status(201).json({ message: "Ny user er oprettet", ny: user });
        }
    }
    catch (error) {
        res.status(400).json({ message: "Der er sket en fejl", error: error.message });
    }

});



// ----- SLET/DELETE ------------------------------------------------------------------------------------------------------------- 

router.delete('/admin/:id', findUser, async (req, res) => {
    
    console.log("DELETE")

    try {

        await res.user.remove();
        res.status(200).json({ message: 'Der er nu slettet' })

    } catch (error) {
        res.json(500).json({ message: 'Der kan ikke slettes - der er opstået en fejl: ' + error.message })
    }

});


// ----- RET/PUT ------------------------------------------------------------------------------------------------------------- 

router.put('/admin/:id', findUser, async (req, res) => {

    console.log("PUT")

    try {

        res.user.email = req.body.email;
        res.user.password = req.body.password;

        await res.user.save();
        res.status(200).json({ message: 'Der er rettet', rettetadminbruger: res.user });

    } catch (error) {
        res.status(400).json({ message: 'Der kan ikke rettes - der er opstået en fejl: ' + error.message })

    }

});



// MIDDLEWARE 

// FIND FRA ID  ---------------------------------------------------------------------------------------------

async function findUser(req, res, next) {

    console.log("FIND UD FRA ID", req.params.id)
    let user;

    try {

        user = await Users.findById(req.params.id);

        if (user == null) {
            return res.status(404).json({ message: 'Der findes ikke en  med den ID' });
        }


    } catch (error) {

        console.log(error);
        return res.status(500).json({ message: "Problemer: " + error.message }); // problemer med server
    }

    res.user = user; // put det fundne ind i responset
    next();
}


module.exports = router;
