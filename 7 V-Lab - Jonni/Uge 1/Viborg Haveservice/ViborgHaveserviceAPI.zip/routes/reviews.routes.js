const Review = require('../models/reviews.model');

const express = require('express');
const formData = require('express-form-data');              // HVIS der bruges multer et sted så skal denne kun placeres i routes UDEN multer!!!

const router = express.Router();
router.use(formData.parse());  



// ----- HENT/GET ALLE ------------------------------------------------------------------------------------------

router.get('/', async (req, res) => {

    console.log("HENT ALLE");

    try {
        const review = await Review.find();

        res.json(review);

    } catch (err) {
        res.status(500).json({ message: "Der var en fejl i / :" + err.message }); // 500 = serverproblem
    }

});


// ----- HENT/GET UDVALGT  ------------------------------------------------------------------------------------------------------------- 

router.get('/:id', findReview, async (req, res) => { //

    console.log("HENT UDVALGT")

    res.json(res.review);

});


// ----- OPRET/POST NY - ADMIN ---------------------------------------------------------------------------------------

router.post('/admin', async (req, res) => {

    console.log("POST");

    const review = new Review(req.body);

    try {
        const ny = await review.save();
        res.status(201).json({ message: "Ny er oprettet", review: ny });

    } catch (error) {
        res.status(400).json({ message: "Der er sket en fejl", error: error });
    }

});



// ----- SLET/DELETE - ADMIN ------------------------------------------------------------------------------------------------------------ 

router.delete('/admin/:id', findReview, async (req, res) => {

    console.log("DELETE")

    try {

        await res.review.remove();
        res.status(200).json({ message: 'Der er nu slettet' })

    } catch (error) {
        res.status(500).json({ message: 'Der kan ikke slettes - der er opstået en fejl: ' + error.message })
    }



});

// ----- RET/PUT - ADMIN ------------------------------------------------------------------------------------------------------------ 

router.put('/admin/:id', findReview, async (req, res) => {

    console.log("PUT")

    try {

        // Husk at id ikke er med i req.body - derfor dur det ikke med res.gaade = req.body;
        res.review.author = req.body.author;
        res.review.content = req.body.content;

        await res.review.save();
        res.status(200).json({ message: 'Der er rettet', rettet: res.review });

    } catch (error) {
        res.status(400).json({ message: 'Der kan ikke rettes - der er opstået en fejl: ' + error.message })
    }

});



// MIDDLEWARE 

// FIND UD FRA ID  ---------------------------------------------------------------------------------------------

async function findReview(req, res, next) {

    console.log("FIND UD FRA ID")
    let review;

    try {

        review = await Review.findById(req.params.id);

        if (review == null) {
            return res.status(404).json({ message: 'Ingen  med den ID' });
        }


    } catch (error) {

        console.log(error);
        return res.status(500).json({ message: "Problemer: " + error.message }); // problemer med server
    }

    res.review = review; // put det fundne ind i responset
    next();
}


module.exports = router;