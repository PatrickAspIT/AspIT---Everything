const Contactform = require('../models/contactform.model');

const express = require('express');
const formData = require('express-form-data');              // HVIS der bruges multer et sted så skal denne kun placeres i routes UDEN multer!!!

const router = express.Router();
router.use(formData.parse());                               // nødvendig for at kunne modtage formdata fx 'e.target' fra react/frontend



// ----- HENT/GET ALLE ------------------------------------------------------------------------------------------

router.get('/', async (req, res) => {

    console.log("HENT ALLE");

    try {
        const contactform = await Contactform.find();

        res.json(contactform);

    } catch (err) {
        res.status(500).json({ message: "Der var en fejl i: " + err.message }); // 500 = serverproblem
    }

});



// ----- HENT/GET UDVALGT  ------------------------------------------------------------------------------------------------------------- 

router.get('/:id', findContactform, async (req, res) => { //

    console.log("HENT UDVALGT")

    res.json(res.contactform);

});



// ----- OPRET/POST NY - IKKE ADMIN ---------------------------------------------------------------------------------------

router.post('/', async (req, res) => {

    console.log("POST");

    const contactform = new Contactform(req.body);

    try {
        const ny = await contactform.save();
        res.status(201).json({ message: "Ny er oprettet", contactform: ny });

    } catch (error) {
        res.status(400).json({ message: "Der er sket en fejl", error: error });
    }

});



// ----- SLET/DELETE - ADMIN ------------------------------------------------------------------------------------------------------------- 

router.delete('/admin/:id', findContactform, async (req, res) => {

    console.log("DELETE")

    try {

        await res.contactform.remove();
        res.status(200).json({ message: 'Der er nu slettet' })

    } catch (error) {
        res.status(500).json({ message: 'Der kan ikke slettes - der er opstået en fejl: ' + error.message })
    }



});



// ----- RET/PUT - ADMIN ------------------------------------------------------------------------------------------------------------ 

// Det giver ingen mening at admin kan rette i beskeder fra brugerne!



// MIDDLEWARE 

// FIND UD FRA ID  ---------------------------------------------------------------------------------------------

async function findContactform(req, res, next) {

    console.log("FIND UD FRA ID")
    let contactform;

    try {

        contactform = await Contactform.findById(req.params.id);

        if (contactform == null) {
            return res.status(404).json({ message: 'Ingen  med den ID' });
        }


    } catch (error) {

        console.log(error);
        return res.status(500).json({ message: "Problemer: " + error.message }); // problemer med server
    }

    res.contactform = contactform; // put det fundne ind i responset
    next();
}


module.exports = router;