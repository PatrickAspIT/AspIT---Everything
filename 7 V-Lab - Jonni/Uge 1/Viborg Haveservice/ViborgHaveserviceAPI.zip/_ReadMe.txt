
//////////// OPSTART //////////////////////////

Installer føst backend med kommando i terminal i roden af projektet: 

        npm install



//////////// OPSÆTNING  //////////////////////////

I mappen _OPSÆTNING ligger 2 mapper:

   1) "collections og data til mongodb" indeholdende:
        8 json-collections med data til installation i Mongodatabase

        - følg instruktionen i txt-filen i samme mappe for at installere collections og documents/data
        - efter installation burde du have følgende:

        Databasen: viborghaveservice
        Collections: aboutus, contactforms, contacts, galleryitems, reviews, services, toast, user


    2) "Postman til import"
        - 1 postman collection til import i Postman-programmet - med alle metoder (GET POST PUT DELETE)


//////////// START ///////////////////////////////

Projektet startes med:

    npm start (produktion = skal genstartes hvis der ændres i server mv.)
    eller
    npm devStart (developer = genstarter automatisk ved rettelser)

Porten er 5023 men kan ændres i .env-filen. Hvis den ændres, så husk at også stien til images (herunder) ændres tilsvarende.



//////////// API-metoder /////////////////////////

- kan testes i rest-filerne i resttest-mappen

- dokumentation i Postman her: https://documenter.getpostman.com/view/12464673/TVK75fCW

- Postman-collection (i mappen i _OPSÆTNING) kan importes og testes i egen installation af Postman
    
    - husk først at starte API'et (se afsnittet START)



//////////// Images //////////////////////////////

Images/billeder ligger i/skal uploades til mappen: public/images men "public" skal ikke indgå i stien udefra:

Alle billeder ligger på/kan hentes fra adressen: http://localhost:5023/images/XXXX.jpg



//////////// Bruger til login:  //////////////////

    "email": "admin@vh.dk"
    "password": "admin123"


